<?php

return [
    'sidebar' => [
        'account_controls' => 'Contrôles de compte',
        'account_security' => 'Sécurité du compte ',
        'account_settings' => 'Paramètres de Compte',
        'files' => 'Gestionnaire de Fichiers',
        'manage' => 'Gérer le Serveur',
        'overview' => "Vue d'ensemble du serveur",
    ],
];
